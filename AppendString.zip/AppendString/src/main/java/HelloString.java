
public class HelloString {
	public String helloString(String str) {
		return "Hello ".concat(str);

}
}
