

	
	import java.io.BufferedReader;
	import java.io.IOException;
	import java.io.InputStreamReader;
	import java.net.HttpURLConnection;
	import java.net.URL;
	import java.util.Scanner;

	public class HelloStringClient {

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        System.out.println("Enter the input:");
	        String str = scanner.nextLine();


	        scanner.close();

	        try {
	            // URL of the server-side web service
	            URL url = new URL("http://localhost:8081/AppendString/services/HelloString/helloString?str=" + str);

	            // Open a connection to the URL
	            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

	            // Set the request method to GET
	            connection.setRequestMethod("GET");

	            // Read the response from the server
	            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	            String response = reader.readLine();
	            reader.close();

	            // Print the result obtained from the server
	            System.out.println("Result from server: " + response);

	            // Disconnect the connection
	            connection.disconnect();

	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}
