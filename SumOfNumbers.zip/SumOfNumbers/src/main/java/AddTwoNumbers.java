
public class AddTwoNumbers {
	
	public int addTwoNumbers(int a, int b) {
		
		return a+b;
	}

}
